#include<stdio.h>
#include<stdlib.h>
#include<time.h>

void create(int m,int n,int mat[n][m],int proc_min,int proc_max){

    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            mat[i][j]=0;
        }
    }

    int gornja_granica=m*n*proc_max/100;
    int donja_granica=m*n*proc_min/100;

    int slucajan=rand()%(gornja_granica-donja_granica+1)+donja_granica;


    int broj_nula=m*n;



    while(broj_nula>=slucajan){

        int rand_i=rand()%n;
        int rand_j=rand()%m;

        if(mat[rand_i][rand_j]==0){
            mat[rand_i][rand_j]=1;
            broj_nula--;
        }
    }
}

void transformToCSR(int m,int n,int mat[n][m],int A[],int IA[],int JA[],int *pozicija){

    *pozicija=0;

    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){

            if(mat[i][j]!=0){

                A[*pozicija]=mat[i][j];
                IA[*pozicija]=i;
                JA[*pozicija]=j;
                (*pozicija)++;
            }
        }
    }
}

void sum(int m,int n,int A[n][m],int B[n][m],int C[n][m]){
    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            C[i][j]=A[i][j]+B[i][j];
        }
    }
}

void product(int m,int n,int p,int A[n][m],int B[m][p],int C[n][p]){
    int suma;
    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++ ){
                suma=0;
            for(int k=0; k<m; k++){
                    suma+=A[i][k]*B[k][j];
                    C[i][j]=suma;
            }
        }
    }
}
double vrijeme(void (*funkcija()) ){
    clock_t pocetak =clock();
    funkcija();
    clock_t kraj=clock();

    double vrijeme=(double)(kraj-pocetak)/CLOCKS_PER_SEC;

    return vrijeme;
}

void ispis(int m,int n,int mat[n][m]){
    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            printf("%d ",mat[i][j]);
        }
        printf("\n");
    }
}

int br_nula(int n,int m,int mat[n][m]){
    int br=0;
    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            if(mat[i][j]==0)
                br++;
    }
}
return br;
}
void sum1(int k,int A[],int AI[],int AJ[],int B[],int BI[],int BJ[],int C[],int CI[],int CJ[],int mat[][k],int mat1[][k],int mat2[][k]){
    for(int i=0;i<k;i++){
        mat[0][i]=A[i];
    }
    for(int i=0;i<k;i++){
        mat[1][i]=AI[i];
    }
    for(int i=0;i<k;i++){
        mat[2][i]=AJ[i];
    }
    for(int i=0;i<k;i++){
        mat1[0][i]=B[i];
    }
    for(int i=0;i<k;i++){
        mat1[1][i]=BI[i];
    }
    for(int i=0;i<k;i++){
        mat1[2][i]=BJ[i];
    }
    for(int i=0;i<3;i++){
        for(int j=0;j<k;j++){
            mat2[i][j]=mat[i][j]+mat1[i][j];
        }
    }
}
int main(){
    int pozicija;
    int mat[10][10];
    create(10,10,mat,50,70);
    int A[100],IA[100],JA[100];
    transformToCSR(10,10,mat,A,IA,JA,&pozicija);
    srand(time(NULL));


    printf("Ispis matrice:\n");

    int K[500][500];
    int B[500][500];
    int C[500][500];
    int M[500][500];
    create(500,500,K,50,60);
 //   ispis(10,10,K);
 //   printf("\n");
    create(500,500,B,50,60);
    sum(500,500,K,B,C);
    ispis(500,500,C);

 /*   create(10,10,K,40,50);
    create(10,10,K,40,50);
    create(10,10,K,40,50);
    create(10,10,K,40,50);
    create(10,10,K,40,50);
    create(10,10,K,40,50);
    create(10,10,K,40,50);
    create(10,10,K,40,50);
    create(10,10,K,50,60);
    create(10,10,K,50,60);
    create(10,10,K,50,60);
    create(10,10,K,50,60);
    create(10,10,K,50,60);
    create(10,10,K,50,60);
    create(10,10,K,50,60);
    create(10,10,K,50,60);
    create(10,10,K,50,60);
    create(10,10,K,50,60);
    create(10,10,K,60,70);
    create(10,10,K,60,70);
    create(10,10,K,60,70);
    create(10,10,K,60,70);
    create(10,10,K,60,70);
    create(10,10,K,60,70);
    create(10,10,K,60,70);
    create(10,10,K,60,70);
    create(10,10,K,60,70);
    create(10,10,K,60,70);
    create(10,10,K,70,80);
    create(10,10,K,70,80);
    create(10,10,K,70,80);
    create(10,10,K,70,80);
    create(10,10,K,70,80);
    create(10,10,K,70,80);
    create(10,10,K,70,80);
    create(10,10,K,70,80);
    create(10,10,K,70,80);
    create(10,10,K,70,80);
    create(10,10,K,80,90);
    create(10,10,K,80,90);
    create(10,10,K,80,90);
    create(10,10,K,80,90);
    create(10,10,K,80,90);
    create(10,10,K,80,90);
    create(10,10,K,80,90);
    create(10,10,K,80,90);
    create(10,10,K,80,90);
    create(10,10,K,80,90);
    create(10,10,K,90,98);
    create(10,10,K,90,98);
    create(10,10,K,90,98);
    create(10,10,K,90,98);
    create(10,10,K,90,98);
    create(10,10,K,90,98);
    create(10,10,K,90,98);
    create(10,10,K,90,98);
    create(10,10,K,90,98);
    create(10,10,K,90,98);
    create(20,20,K,40,50);
    create(20,20,K,40,50);
    create(20,20,K,40,50);
    create(20,20,K,40,50);
    create(20,20,K,40,50);
    create(20,20,K,40,50);
    create(20,20,K,40,50);
    create(20,20,K,40,50);
    create(20,20,K,40,50);
    create(20,20,K,40,50);
    create(20,20,K,50,60);
    create(20,20,K,50,60);
    create(20,20,K,50,60);
    create(20,20,K,50,60);
    create(20,20,K,50,60);
    create(20,20,K,50,60);
    create(20,20,K,50,60);
    create(20,20,K,50,60);
    create(20,20,K,50,60);
    create(20,20,K,50,60);
    create(20,20,K,60,70);
    create(20,20,K,60,70);
    create(20,20,K,60,70);
    create(20,20,K,60,70);
    create(20,20,K,60,70);
    create(20,20,K,60,70);
    create(20,20,K,60,70);
    create(20,20,K,60,70);
    create(20,20,K,60,70);
    create(20,20,K,60,70);
    create(20,20,K,70,80);
    create(20,20,K,70,80);
    create(20,20,K,70,80);
    create(20,20,K,70,80);
    create(20,20,K,70,80);
    create(20,20,K,70,80);
    create(20,20,K,70,80);
    create(20,20,K,70,80);
    create(20,20,K,70,80);
    create(20,20,K,70,80);
    create(20,20,K,80,90);
    create(20,20,K,80,90);
    create(20,20,K,80,90);
    create(20,20,K,80,90);
    create(20,20,K,80,90);
    create(20,20,K,80,90);
    create(20,20,K,80,90);
    create(20,20,K,80,90);
    create(20,20,K,80,90);
    create(20,20,K,80,90);
    create(20,20,K,90,98);
    create(20,20,K,90,98);
    create(20,20,K,90,98);
    create(20,20,K,90,98);
    create(20,20,K,90,98);
    create(20,20,K,90,98);
    create(20,20,K,90,98);
    create(20,20,K,90,98);
    create(20,20,K,90,98);
    create(20,20,K,90,98);
    create(30,30,K,40,50);
    create(30,30,K,40,50);
    create(30,30,K,40,50);
    create(30,30,K,40,50);
    create(30,30,K,40,50);
    create(30,30,K,40,50);
    create(30,30,K,40,50);
    create(30,30,K,40,50);
    create(30,30,K,40,50);
    create(30,30,K,40,50);
    create(30,30,K,50,60);
    create(30,30,K,50,60);
    create(30,30,K,50,60);
    create(30,30,K,50,60);
    create(30,30,K,50,60);
    create(30,30,K,50,60);
    create(30,30,K,50,60);
    create(30,30,K,50,60);
    create(30,30,K,50,60);
    create(30,30,K,50,60);
    create(30,30,K,60,70);
    create(30,30,K,60,70);
    create(30,30,K,60,70);
    create(30,30,K,60,70);
    create(30,30,K,60,70);
    create(30,30,K,60,70);
    create(30,30,K,60,70);
    create(30,30,K,60,70);
    create(30,30,K,60,70);
    create(30,30,K,60,70);
    create(30,30,K,70,80);
    create(30,30,K,70,80);
    create(30,30,K,70,80);
    create(30,30,K,70,80);
    create(30,30,K,70,80);
    create(30,30,K,70,80);
    create(30,30,K,70,80);
    create(30,30,K,70,80);
    create(30,30,K,70,80);
    create(30,30,K,70,80);
    create(30,30,K,80,90);
    create(30,30,K,80,90);
    create(30,30,K,80,90);
    create(30,30,K,80,90);
    create(30,30,K,80,90);
    create(30,30,K,80,90);
    create(30,30,K,80,90);
    create(30,30,K,80,90);
    create(30,30,K,80,90);
    create(30,30,K,80,90);
    create(30,30,K,90,98);
    create(30,30,K,90,98);
    create(30,30,K,90,98);
    create(30,30,K,90,98);
    create(30,30,K,90,98);
    create(30,30,K,90,98);
    create(30,30,K,90,98);
    create(30,30,K,90,98);
    create(30,30,K,90,98);
    create(30,30,K,90,98);
    create(50,50,K,40,50);
    create(50,50,K,40,50);
    create(50,50,K,40,50);
    create(50,50,K,40,50);
    create(50,50,K,40,50);
    create(50,50,K,40,50);
    create(50,50,K,40,50);
    create(50,50,K,40,50);
    create(50,50,K,40,50);
    create(50,50,K,40,50);
    create(50,50,K,50,60);
    create(50,50,K,50,60);
    create(50,50,K,50,60);
    create(50,50,K,50,60);
    create(50,50,K,50,60);
    create(50,50,K,50,60);
    create(50,50,K,50,60);
    create(50,50,K,50,60);
    create(50,50,K,50,60);
    create(50,50,K,50,60);
    create(50,50,K,60,70);
    create(50,50,K,60,70);
    create(50,50,K,60,70);
    create(50,50,K,60,70);
    create(50,50,K,60,70);
    create(50,50,K,60,70);
    create(50,50,K,60,70);
    create(50,50,K,60,70);
    create(50,50,K,60,70);
    create(50,50,K,60,70);
    create(50,50,K,70,80);
    create(50,50,K,70,80);
    create(50,50,K,70,80);
    create(50,50,K,70,80);
    create(50,50,K,70,80);
    create(50,50,K,70,80);
    create(50,50,K,70,80);
    create(50,50,K,70,80);
    create(50,50,K,70,80);
    create(50,50,K,70,80);
    create(50,50,K,80,90);
    create(50,50,K,80,90);
    create(50,50,K,80,90);
    create(50,50,K,80,90);
    create(50,50,K,80,90);
    create(50,50,K,80,90);
    create(50,50,K,80,90);
    create(50,50,K,80,90);
    create(50,50,K,80,90);
    create(50,50,K,80,90);
    create(50,50,K,90,98);
    create(50,50,K,90,98);
    create(50,50,K,90,98);
    create(50,50,K,90,98);
    create(50,50,K,90,98);
    create(50,50,K,90,98);
    create(50,50,K,90,98);
    create(50,50,K,90,98);
    create(50,50,K,90,98);
    create(50,50,K,90,98);
    create(70,70,K,40,50);
    create(70,70,K,40,50);
    create(70,70,K,40,50);
    create(70,70,K,40,50);
    create(70,70,K,40,50);
    create(70,70,K,40,50);
    create(70,70,K,40,50);
    create(70,70,K,40,50);
    create(70,70,K,40,50);
    create(70,70,K,40,50);
    create(70,70,K,50,60);
    create(70,70,K,50,60);
    create(70,70,K,50,60);
    create(70,70,K,50,60);
    create(70,70,K,50,60);
    create(70,70,K,50,60);
    create(70,70,K,50,60);
    create(70,70,K,50,60);
    create(70,70,K,50,60);
    create(70,70,K,50,60);
    create(70,70,K,60,70);
    create(70,70,K,60,70);
    create(70,70,K,60,70);
    create(70,70,K,60,70);
    create(70,70,K,60,70);
    create(70,70,K,60,70);
    create(70,70,K,60,70);
    create(70,70,K,60,70);
    create(70,70,K,60,70);
    create(70,70,K,60,70);
    create(70,70,K,70,80);
    create(70,70,K,70,80);
    create(70,70,K,70,80);
    create(70,70,K,70,80);
    create(70,70,K,70,80);
    create(70,70,K,70,80);
    create(70,70,K,70,80);
    create(70,70,K,70,80);
    create(70,70,K,70,80);
    create(70,70,K,70,80);
    create(70,70,K,80,90);
    create(70,70,K,80,90);
    create(70,70,K,80,90);
    create(70,70,K,80,90);
    create(70,70,K,80,90);
    create(70,70,K,80,90);
    create(70,70,K,80,90);
    create(70,70,K,80,90);
    create(70,70,K,80,90);
    create(70,70,K,80,90);
    create(70,70,K,80,90);
    create(70,70,K,90,98);
    create(70,70,K,90,98);
    create(70,70,K,90,98);
    create(70,70,K,90,98);
    create(70,70,K,90,98);
    create(70,70,K,90,98);
    create(70,70,K,90,98);
    create(70,70,K,90,98);
    create(70,70,K,90,98);
    create(70,70,K,90,98);
    create(100,100,K,40,50);
    create(100,100,K,40,50);
    create(100,100,K,40,50);
    create(100,100,K,40,50);
    create(100,100,K,40,50);
    create(100,100,K,40,50);
    create(100,100,K,40,50);
    create(100,100,K,40,50);
    create(100,100,K,40,50);
    create(100,100,K,40,50);
    create(100,100,K,50,60);
    create(100,100,K,50,60);
    create(100,100,K,50,60);
    create(100,100,K,50,60);
    create(100,100,K,50,60);
    create(100,100,K,50,60);
    create(100,100,K,50,60);
    create(100,100,K,50,60);
    create(100,100,K,50,60);
    create(100,100,K,50,60);
    create(100,100,K,60,70);
    create(100,100,K,60,70);
    create(100,100,K,60,70);
    create(100,100,K,60,70);
    create(100,100,K,60,70);
    create(100,100,K,60,70);
    create(100,100,K,60,70);
    create(100,100,K,60,70);
    create(100,100,K,60,70);
    create(100,100,K,60,70);
    create(100,100,K,70,80);
    create(100,100,K,70,80);
    create(100,100,K,70,80);
    create(100,100,K,70,80);
    create(100,100,K,70,80);
    create(100,100,K,70,80);
    create(100,100,K,70,80);
    create(100,100,K,70,80);
    create(100,100,K,70,80);
    create(100,100,K,70,80);
    create(100,100,K,80,90);
    create(100,100,K,80,90);
    create(100,100,K,80,90);
    create(100,100,K,80,90);
    create(100,100,K,80,90);
    create(100,100,K,80,90);
    create(100,100,K,80,90);
    create(100,100,K,80,90);
    create(100,100,K,80,90);
    create(100,100,K,80,90);
    create(100,100,K,90,98);
    create(100,100,K,90,98);
    create(100,100,K,90,98);
    create(100,100,K,90,98);
    create(100,100,K,90,98);
    create(100,100,K,90,98);
    create(100,100,K,90,98);
    create(100,100,K,90,98);
    create(100,100,K,90,98);
    create(100,100,K,90,98);
    create(500,500,K,40,50);
    create(500,500,K,40,50);
    create(500,500,K,40,50);
    create(500,500,K,40,50);
    create(500,500,K,40,50);
    create(500,500,K,40,50);
    create(500,500,K,40,50);
    create(500,500,K,40,50);
    create(500,500,K,40,50);
    create(500,500,K,40,50);
    create(500,500,K,50,60);
    create(500,500,K,50,60);
    create(500,500,K,50,60);
    create(500,500,K,50,60);
    create(500,500,K,50,60);
    create(500,500,K,50,60);
    create(500,500,K,50,60);
    create(500,500,K,50,60);
    create(500,500,K,50,60);
    create(500,500,K,50,60);
    create(500,500,K,60,70);
    create(500,500,K,60,70);
    create(500,500,K,60,70);
    create(500,500,K,60,70);
    create(500,500,K,60,70);
    create(500,500,K,60,70);
    create(500,500,K,60,70);
    create(500,500,K,60,70);
    create(500,500,K,60,70);
    create(500,500,K,60,70);
    create(500,500,K,70,80);
    create(500,500,K,70,80);
    create(500,500,K,70,80);
    create(500,500,K,70,80);
    create(500,500,K,70,80);
    create(500,500,K,70,80);
    create(500,500,K,70,80);
    create(500,500,K,70,80);
    create(500,500,K,70,80);
    create(500,500,K,70,80);
    create(500,500,K,80,90);
    create(500,500,K,80,90);
    create(500,500,K,80,90);
    create(500,500,K,80,90);
    create(500,500,K,80,90);
    create(500,500,K,80,90);
    create(500,500,K,80,90);
    create(500,500,K,80,90);
    create(500,500,K,80,90);
    create(500,500,K,80,90);
    create(500,500,K,90,98);
    create(500,500,K,90,98);
    create(500,500,K,90,98);
    create(500,500,K,90,98);
    create(500,500,K,90,98);
    create(500,500,K,90,98);
    create(500,500,K,90,98);
    create(500,500,K,90,98);
    create(500,500,K,90,98);
    create(500,500,K,90,98);*/


 /*   create(10,10,B,20,30);
    create(10,10,M,20,30);
    printf("\n");
    ispis(10,10,M);
    printf("\n");
    printf("Matrica K:\n");
    ispis(10,10,K);
    printf("Matrica B:\n");
    ispis(10,10,B);
    ispis(10,10,C);*/

   /* create(500,500,M,60,70);
    printf("\n niz A:");
    for(int i=0; i<pozicija; i++){
        printf(" %d",A[i]);
    }
    printf("\n niz IA:");
    for(int i=0; i<pozicija; i++){
        printf(" %d",IA[i]);
    }
    printf("\n niz JA:");
    for(int i=0; i<pozicija; i++){
        printf(" %d",JA[i]);
    }
    */
 /*   printf("Suma matrica A1 i B:\n");
    sum(10,10,K,B,C);
    ispis(10,10,C);
    printf("\n");
    printf("Proizvod matrica A1 i B:\n");
    product(10,10,10,K,B,C);
    ispis(10,10,C);
    ispis(500,500,M);
    printf("%d",br_nula(500,500,M));*/
return 0;
}
