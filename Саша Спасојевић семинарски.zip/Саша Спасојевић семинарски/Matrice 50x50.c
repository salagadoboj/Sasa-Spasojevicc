#include<stdio.h>
#include<stdlib.h>
#include<time.h>

void create(int m,int n,int mat[n][m],int proc_min,int proc_max){

    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            mat[i][j]=0;
        }
    }

    int gornja_granica=m*n*proc_max/100;
    int donja_granica=m*n*proc_min/100;

    int slucajan=rand()%(gornja_granica-donja_granica+1)+donja_granica;


    int broj_nula=m*n;



    while(broj_nula>=slucajan){

        int rand_i=rand()%n;
        int rand_j=rand()%m;

        if(mat[rand_i][rand_j]==0){
            mat[rand_i][rand_j]=1;
            broj_nula--;
        }
    }
}

void transformToCSR(int m,int n,int mat[n][m],int A[],int IA[],int JA[],int *poz){

    *poz=0;

    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){

            if(mat[i][j]!=0){

                A[*poz]=mat[i][j];
                IA[*poz]=i;
                JA[*poz]=j;
                (*poz)++;
            }
        }
    }
}

void sum(int m,int n,int A[n][m],int B[n][m],int C[n][m]){
    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            C[i][j]=A[i][j]+B[i][j];
        }
    }
}

void product(int m,int n,int p,int A[n][m],int B[m][p],int C[n][p]){
    int suma;
    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++ ){
                suma=0;
            for(int k=0; k<m; k++){
                    suma+=A[i][k]*B[k][j];
                    C[i][j]=suma;
            }
        }
    }
}
double vrijeme(void (*funkcija()) ){
    clock_t pocetak =clock();
    funkcija();
    clock_t kraj=clock();

    double vrijeme=(double)(kraj-pocetak)/CLOCKS_PER_SEC;

    return vrijeme;
}

void ispis(int m,int n,int mat[n][m]){
    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            printf("%d ",mat[i][j]);
        }
        printf("\n");
    }
}

int br_nula(int n,int m,int mat[n][m]){
    int br=0;
    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            if(mat[i][j]==0)
                br++;
    }
}
return br;
}
void sum1(int k,int A[],int AI[],int AJ[],int B[],int BI[],int BJ[],int C[],int CI[],int CJ[],int mat[][k],int mat1[][k],int mat2[][k]){
    for(int i=0;i<k;i++){
        mat[0][i]=A[i];
    }
    for(int i=0;i<k;i++){
        mat[1][i]=AI[i];
    }
    for(int i=0;i<k;i++){
        mat[2][i]=AJ[i];
    }
    for(int i=0;i<k;i++){
        mat1[0][i]=B[i];
    }
    for(int i=0;i<k;i++){
        mat1[1][i]=BI[i];
    }
    for(int i=0;i<k;i++){
        mat1[2][i]=BJ[i];
    }
    for(int i=0;i<3;i++){
        for(int j=0;j<k;j++){
            mat2[i][j]=mat[i][j]+mat1[i][j];
        }
    }
}
int main(){
    srand(time(NULL));
    printf("Ispis matrice:\n");
    int Q[50][50],W[50][50],E[50][50],R[50][50],T[50][50],Y[50][50],U[50][50],I[50][50],O[50][50],P[50][50],A[50][50],S[50][50],D[50][50],F[50][50],G[50][50],H[50][50],J[50][50],L[50][50],K[50][50],Z[50][50],X[50][50],C[50][50],V[50][50],B[50][50],N[50][50],M[50][50],Q1[50][50],W1[50][50],E1[50][50],R1[15][50],T1[50][50],Y1[50][50],U1[50][50],I1[50][50],O1[50][50],P1[50][50],A1[50][50],S1[50][50],D1[50][50],F1[50][50],G1[50][50],H1[50][50],J1[50][50],K1[50][50],L1[50][50],Z1[50][50],X1[50][50],C1[50][50],V1[50][50],B1[50][50],N1[50][50],M1[50][50],Q2[50][50],W2[50][50],E2[50][50],R2[50][50],T2[50][50],Y2[50][50],U2[50][50],I2[50][50];
    int suma1[50][50],suma2[50][50],suma3[50][50],suma4[50][50],suma5[50][50],proizvod1[50][50],proizvod2[50][50],proizvod3[50][50],proizvod4[50][50],proizvod5[50][50];

    create(50,50,Q,40,50);
    create(50,50,W,40,50);
    sum(50,50,Q,W,suma1);
    product(50,50,50,Q,W,proizvod1);
    ispis(50,50,suma1);
    printf("\n");
    ispis(50,50,proizvod1);
    printf("\n");
    create(50,50,E,40,50);
    create(50,50,R,40,50);
    sum(50,50,E,R,suma2);
    product(50,50,50,Q,W,proizvod2);
    ispis(50,50,suma2);
    printf("\n");
    ispis(50,50,proizvod2);
    printf("\n");
    create(50,50,T,40,50);
    create(50,50,Y,40,50);
    sum(50,50,T,Y,suma3);
    product(50,50,50,Q,W,proizvod3);
    ispis(50,50,suma3);
    printf("\n");
    ispis(50,50,proizvod3);
    printf("\n");
    create(50,50,U,40,50);
    create(50,50,I,40,50);
    sum(50,50,U,I,suma4);
    product(50,50,50,Q,W,proizvod4);
    ispis(50,50,suma4);
    printf("\n");
    ispis(50,50,proizvod4);
    printf("\n");
    create(50,50,O,40,50);
    create(50,50,P,40,50);
    sum(50,50,O,P,suma5);
    product(50,50,50,Q,W,proizvod5);
    ispis(50,50,suma5);
    printf("\n");
    ispis(50,50,proizvod5);
    printf("\n");
    //Sume i proizvode ispisujemo isto i za ostale matrice.Njihove rezultate cemo samo upisati u tabelu.
    create(50,50,A,50,60);
    create(50,50,S,50,60);
    create(50,50,D,50,60);
    create(50,50,F,50,60);
    create(50,50,G,50,60);
    create(50,50,H,50,60);
    create(50,50,J,50,60);
    create(50,50,K,50,60);
    create(50,50,L,50,60);
    create(50,50,Z,50,60);
    create(50,50,X,60,70);
    create(50,50,C,60,70);
    create(50,50,V,60,70);
    create(50,50,B,60,70);
    create(50,50,N,60,70);
    create(50,50,M,60,70);
    create(50,50,Q1,60,70);
    create(50,50,W1,60,70);
    create(50,50,E1,60,70);
    create(50,50,R1,60,70);
    create(50,50,T1,70,80);
    create(50,50,Y1,70,80);
    create(50,50,U1,70,80);
    create(50,50,I1,70,80);
    create(50,50,O1,70,80);
    create(50,50,P1,70,80);
    create(50,50,A1,70,80);
    create(50,50,S1,70,80);
    create(50,50,D1,70,80);
    create(50,50,F1,70,80);
    create(50,50,G1,80,90);
    create(50,50,H1,80,90);
    create(50,50,J1,80,90);
    create(50,50,K1,80,90);
    create(50,50,L1,80,90);
    create(50,50,Z1,80,90);
    create(50,50,X1,80,90);
    create(50,50,C1,80,90);
    create(50,50,V1,80,90);
    create(50,50,B1,80,90);
    create(50,50,N1,90,98);
    create(50,50,M1,90,98);
    create(50,50,Q2,90,98);
    create(50,50,W2,90,98);
    create(50,50,E2,90,98);
    create(50,50,R2,90,98);
    create(50,50,T2,90,98);
    create(50,50,Y2,90,98);
    create(50,50,U2,90,98);
    create(50,50,I2,90,98);


return 0;
}

